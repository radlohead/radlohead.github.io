import React from 'react';
import { connect } from 'react-redux';
import { Route } from 'react-router-dom';
import { Menu, Home, Products, WishList } from '../components/index';

class Containers extends React.Component {
	render() {
		return (
			<>
				<Menu />
				<Route exact path="/" component={Home} />
				<Route path="/products" component={Products} />
				<Route path="/wishlist" component={WishList} />
			</>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		currentPage: state.page.currentPage
	}
}

export default connect(mapStateToProps)(Containers);
