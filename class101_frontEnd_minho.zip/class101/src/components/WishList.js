import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
    RATE,
    AMOUNT,
    setWishListAdd,
    setWishListRemove,
    setWishListItemCheck,
    setWishListItemCount,
    fetchCouponsItems
} from '../actions';
import '../css/components/WishList.scss';

class WishList extends React.Component {
    constructor(props) {
        super(props);
        const { onFetchCouponsItems } = this.props;
        onFetchCouponsItems();
    }

    handleCheckItem(item) {
        const { cart, onSetWishListItemCheck } = this.props;
        const checkedIndex = cart.findIndex(v => v.id === item.id && v.score === item.score);

        cart[checkedIndex].checked = !cart[checkedIndex].checked;
        onSetWishListItemCheck(cart);
        
        ReactDOM.render(
            this.renderCart(cart),
            ReactDOM.findDOMNode(this.refs['WishList'])
        );
    }

    handleChangeCount(item, e) {
        const { cart, onSetWishListItemCount } = this.props;
        const changeIndex = cart.findIndex(v => v.id === item.id && v.score === item.score);

        if(e.target.value < 0) return;
        cart[changeIndex].count = e.target.value;
        onSetWishListItemCount(cart);

        ReactDOM.render(
            this.renderCart(cart),
            ReactDOM.findDOMNode(this.refs['WishList'])
        );

        ReactDOM.render(
            this.renderTotalPrice(),
            ReactDOM.findDOMNode(this.refs['TotalPrice'])
        );
    }

    getCouponApplyItemsTotalPrice() {
        const { cart } = this.props;
        if(!cart.length) return 0;
        const couponApplyItems = cart.filter(item => item.availableCoupon === undefined);
        if(!couponApplyItems.length) return 0;

        return couponApplyItems
                .map(item => item.price * Number(item.count))
                .reduce((a, b) => a + b);
    }

    getCouponNotApplyItemsTotalPrice() {
        const { cart } = this.props;
        if(!cart.length) return 0;
        const couponNotApplyItems = cart.filter(item => item.availableCoupon === false);
        if(!couponNotApplyItems.length) return 0;

        return couponNotApplyItems
                .map(item => item.price * Number(item.count))
                .reduce((a, b) => a + b);
    }

    getTotalCouponPrice(coupon) {
        const { cart } = this.props;
        if(!cart.length) return '0';
        if(!coupon) return this.getTotalPrice();
        
        coupon = JSON.parse(coupon);
        const amountPrice = this.getCouponApplyItemsTotalPrice() - coupon.discountAmount;
        let result = null;

        switch(coupon.type.toUpperCase()) {
            case RATE:
                result= Math.floor(this.getCouponApplyItemsTotalPrice() * ((100 - coupon.discountRate) * 0.01));
                break;
            case AMOUNT:
                result = amountPrice > 0 ? amountPrice : 0;
                break;
            default:
                result = this.getCouponApplyItemsTotalPrice();
        }
        
        return result + this.getCouponNotApplyItemsTotalPrice();
    }

    handleChangeCoupon(e) {
        ReactDOM.render(
            this.renderTotalPrice(e.target.value),
            ReactDOM.findDOMNode(this.refs['TotalPrice'])
        );
    }

    getTotalPrice() {
        const { cart } = this.props;
        if(!cart.length) return 0;

        return cart
            .map(item => item.price * Number(item.count))
            .reduce((a, b) => a + b);
    }

    renderTotalPrice(coupon) {
        return (
            <section>
                <strong>
                    전체 금액: {`${this.getTotalCouponPrice(coupon)}원`}
                </strong>
            </section>
        );
    }

    renderCart(item) {
        const { cart } = this.props;
        if(!cart.length) return null;

        return (
            <ul>
                {cart.map(item => {
                    return <li key={`${item.id}-${item.score}`} className="products-item">
                        <input 
                            type="checkbox" 
                            checked={item.checked} 
                            onChange={() => this.handleCheckItem(item)}
                        />
                        <img src={item.coverImage} alt={item.title} />
                        <strong className="products-item__title">{item.title}</strong>
                        <em className="products-item__price">{item.price}</em>
                        <input 
                            type="number"
                            value={item.count}
                            onChange={this.handleChangeCount.bind(this, item)}
                        />
                </li>})}
            </ul>
        )
    }

    renderCoupons() {
        const { couponsJSON } = this.props;
        if(!couponsJSON) return null;

        return (
            <section className="coupons">
                <select defaultValue="select" onChange={this.handleChangeCoupon.bind(this)}>
                    <option value="">select</option>
                    {couponsJSON.map(item => {
                        return (
                            <option 
                                key={`${item.type}_${item.discountRate}`} 
                                value={JSON.stringify(item)}
                            >{item.title}</option>
                        )
                    })}
                </select>
            </section>
        )
    }

    componentDidMount() {
        const { cart } = this.props;

        ReactDOM.render(
            this.renderCart(cart),
            ReactDOM.findDOMNode(this.refs['WishList'])
        )

        ReactDOM.render(
            this.renderTotalPrice(),
            ReactDOM.findDOMNode(this.refs['TotalPrice'])
        )
    }

    render() {
        return (
            <>
                <section>
                    <div ref="WishList"></div>
                    {this.renderCoupons()}
                    <div ref="TotalPrice" className="total-price"></div>
                </section>
            </>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        cart: state.wishList.cart,
        couponsJSON: state.coupons.couponsJSON
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSetWishListAdd: bindActionCreators(setWishListAdd, dispatch),
        onSetWishListRemove: bindActionCreators(setWishListRemove, dispatch),
        onSetWishListItemCheck: bindActionCreators(setWishListItemCheck, dispatch),
        onSetWishListItemCount: bindActionCreators(setWishListItemCount, dispatch),
        onFetchCouponsItems: bindActionCreators(fetchCouponsItems, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(WishList);