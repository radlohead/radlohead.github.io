import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { fetchProductsItems } from '../actions';
import { setWishListAdd, setWishListRemove, setProductJSON } from '../actions';
import '../css/components/Products.scss';

class Products extends React.Component {
    constructor(props) {
        super(props);
        const { onFetchProductsItems } = this.props;

        onFetchProductsItems();
    }

    productsSortItems() {
        const { productsJSON } = this.props;
        productsJSON.sort((a, b) => a.score - b.score);
    }

    handleClickWishListAdd(item) {
        const { productsJSON, cart, onSetWishListAdd, onSetProductJSON } = this.props;
        const targetIndex = productsJSON.findIndex(v => v.id === item.id && v.score === item.score);

        if(!cart.every(v => v.id !== item.id && v.score !== item.score)) return;
        if(cart.length >= 3) return;
        productsJSON[targetIndex].isInCart = true;

        onSetProductJSON(productsJSON);
        onSetWishListAdd(item);
    }

    handleClickWishListRemove(item) {
        const { cart, productsJSON, onSetWishListRemove, onSetProductJSON } = this.props;
        const deleteItemIndex = cart.findIndex(v => v.id === item.id && v.score === item.score);
        const targetIndex = productsJSON.findIndex(v => v.id === item.id && v.score === item.score);
        
        cart.splice(deleteItemIndex, 1);
        productsJSON[targetIndex].isInCart = false;
        
        onSetProductJSON(productsJSON);
        onSetWishListRemove(cart);
    }

    renderProducts() {
        const { productsJSON } = this.props;
        if(!productsJSON) return null;
        this.productsSortItems();

        return (
            <ul className="products-items">
                {productsJSON && productsJSON.map((item, i) => {
                    if(i > 4) return null;
                    return <li key={`${item.id}-${item.score}`} className="products-item">
                        <img src={item.coverImage} alt={item.title} />
                        <strong className="products-item__title">{item.title}</strong>
                        <em className="products-item__price">{item.price}</em>
                        <span className="products-item__btns">
                            {(item.isInCart === undefined || item.isInCart === false) && <span 
                                className="products-item__add"
                                onClick={() => this.handleClickWishListAdd(item)}
                            >cart 담기</span>}
                            {item.isInCart === true && <span 
                                className="products-item__remove"
                                onClick={() => this.handleClickWishListRemove(item)}
                            >cart 빼기</span>}
                        </span>
                    </li>
                })}
            </ul>
        )
    }

    render() {
        return (
            <>
                {this.renderProducts()}
            </>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        cart: state.wishList.cart,
        currentPage: state.page.currentPage,
        productsJSON: state.products.productsJSON
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchProductsItems: bindActionCreators(fetchProductsItems, dispatch),
        onSetWishListAdd: bindActionCreators(setWishListAdd, dispatch),
        onSetWishListRemove: bindActionCreators(setWishListRemove, dispatch),
        onSetProductJSON: bindActionCreators(setProductJSON, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Products);