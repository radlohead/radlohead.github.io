import React from 'react';
import '../css/components/Home.scss';

const Home = () => {
    return (
        <>
            <h1 class="home">index page</h1>
        </>
    )
}

export default Home;