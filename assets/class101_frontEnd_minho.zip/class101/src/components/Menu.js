import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import { PRODUCTS, WISHLIST, setCurrentPage } from '../actions';
import '../css/components/Menu.scss';

class Menu extends React.Component {
    render() {
        const { onSetCurrentPage } = this.props;

        return (
            <>
                <ul className="menu">
                    <li><Link to="/">Home</Link></li>
                    <li onClick={() => onSetCurrentPage(PRODUCTS)}><Link to="/products">products</Link></li>
                    <li onClick={() => onSetCurrentPage(WISHLIST)}><Link to="/wishlist">wishlist</Link></li>
                </ul>
            </>
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSetCurrentPage: bindActionCreators(setCurrentPage, dispatch)
    }
}

export default connect(null, mapDispatchToProps)(Menu);