export const PRODUCTS_IS_FETCHED = 'PRODUCTS_IS_FETCHED';
export const PRODUCTS_IS_ERROR = 'PRODUCTS_IS_ERROR';
export const COUPONS_IS_FETCHED = 'COUPONS_IS_FETCHED';
export const COUPONS_IS_ERROR = 'COUPONS_IS_ERROR';
export const WISHLIST_ADD = 'WISHLIST_ADD';
export const WISHLIST_REMOVE = 'WISHLIST_REMOVE';
export const WISHLIST_ADD_REMOVE = 'WISHLIST_ADD_REMOVE';
export const WISHLIST_ITEM_CHECK = 'WISHLIST_ITEM_CHECK';
export const WISHLIST_ITEM_COUNT = 'WISHLIST_ITEM_COUNT';
export const TOTAL_PRICE = 'TOTAL_PRICE';
export const SHOPPING_MALL = 'SHOPPING_MALL';
export const PRODUCTS = 'PRODUCTS';
export const WISHLIST = 'WISHLIST';
export const RATE = 'RATE';
export const AMOUNT = 'AMOUNT';

export const setCurrentPage = (pageName) => {
    return {
        type: SHOPPING_MALL,
        currentPage: pageName
    }
}

export const setProductJSON = (item) => {
    return {
        type: WISHLIST_ADD_REMOVE,
        productsJSON: item
    }
}

export const setTotalPrice = (item) => {
    return {
        type: TOTAL_PRICE,
        cart: item
    }
}

export const setWishListItemCount = (item) => {
    return {
        type: WISHLIST_ITEM_COUNT,
        cart: item
    }
}

export const setWishListItemCheck = (item) => {
    return {
        type: WISHLIST_ITEM_CHECK,
        cart: item
    }
}

export const setWishListAdd = (item) => {
    return {
        type: WISHLIST_ADD,
        cart: Object.assign(item, {
            checked: false,
            count: 1
        })
    }
}

export const setWishListRemove = (item) => {
    return {
        type: WISHLIST_REMOVE,
        cart: item
    }
}

export const fetchProductsItems = () => {
    return async (dispatch) => {
        try {
            const response = await fetch('http://localhost:4000/products');
            const responseData = await response.json();

            dispatch({
                type: PRODUCTS_IS_FETCHED,
                productsJSON: responseData
            });
        } catch(err) {
            dispatch({
                type: PRODUCTS_IS_ERROR,
                productsJSON: err
            });
        }
    }
}

export const fetchCouponsItems = () => {
    return async (dispatch) => {
        try {
            const response = await fetch('http://localhost:4000/coupons');
            const responseData = await response.json();
            
            dispatch({
                type: COUPONS_IS_FETCHED,
                couponsJSON: responseData
            });
        } catch(err) {
            dispatch({
                type: COUPONS_IS_ERROR,
                couponsJSON: err
            });
        }
    }
}
