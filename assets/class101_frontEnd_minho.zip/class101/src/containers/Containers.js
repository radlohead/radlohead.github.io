import React from 'react';
import { connect } from 'react-redux';
import { Route } from 'react-router-dom';
import { Menu, Home, Products, WishList } from '../components/index';
import { PRODUCTS, WISHLIST } from '../actions';

class Containers extends React.Component {
	render() {
		const { currentPage } = this.props;

		return (
			<>
				<Menu />
				<Route exact path="/" component={Home} />
				{currentPage === PRODUCTS && <Route path="/products" component={Products} />}
				{currentPage === WISHLIST && <Route path="/wishlist" component={WishList} />}
			</>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		currentPage: state.page.currentPage
	}
}

export default connect(mapStateToProps)(Containers);
