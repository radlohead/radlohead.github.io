import React from 'react';
import Containers from './Containers';

class App extends React.Component {
	render() {
		return (
			<>
				<Containers />
			</>
		)
	}
}

export default App;
