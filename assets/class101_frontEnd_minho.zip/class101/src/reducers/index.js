import { combineReducers } from 'redux';
import {
    PRODUCTS_IS_FETCHED,
    PRODUCTS_IS_ERROR,
    COUPONS_IS_FETCHED,
    COUPONS_IS_ERROR,
    SHOPPING_MALL,
    WISHLIST_ADD,
    WISHLIST_REMOVE,
    WISHLIST_ADD_REMOVE,
    WISHLIST_ITEM_CHECK,
    WISHLIST_ITEM_COUNT,
    TOTAL_PRICE
} from '../actions';

const page = (state = {}, action) => {
    switch(action.type) {
        case SHOPPING_MALL:
            return {
                ...state,
                currentPage: action.currentPage || ''
            }
        default:
            return state;
    }
}

const products = (state = {}, action) => {
    switch(action.type) {
        case PRODUCTS_IS_FETCHED:
            return {
                ...state,
                productsJSON: state.productsJSON || action.productsJSON
            }
        case PRODUCTS_IS_ERROR:
            return {
                ...state,
                productsJSON: action.productsJSON
            }
        default:
            return state;
    }
}

const coupons = (state = {}, action) => {
    switch(action.type) {
        case COUPONS_IS_FETCHED:
            return {
                ...state,
                couponsJSON: state.couponsJSON || action.couponsJSON
            }
        case COUPONS_IS_ERROR:
            return {
                ...state,
                couponsJSON: action.couponsJSON
            }
        default:
            return state;
    }
}

const wishListInitialState = {
    cart: []
}

const wishList = (state = wishListInitialState, action) => {
    switch(action.type) {
        case WISHLIST_ADD:
            return {
                ...state,
                cart: [...state.cart, action.cart]
            }
        case WISHLIST_REMOVE:
            return {
                ...state,
                cart: Object.assign([], action.cart)
            }
        case WISHLIST_ADD_REMOVE:
            return {
                ...state,
                productsJSON: Object.assign({}, action.productsJSON)
            }
        case WISHLIST_ITEM_CHECK:
            return {
                ...state,
                cart: action.cart
            }
        case WISHLIST_ITEM_COUNT:
            return {
                ...state,
                cart: action.cart
            }
        case TOTAL_PRICE:
            return {
                ...state,
                cart: action.cart
            }
        default:
            return state;
    }
}

const reducers = combineReducers({
    page,
    products,
    coupons,
    wishList
});

export default reducers;