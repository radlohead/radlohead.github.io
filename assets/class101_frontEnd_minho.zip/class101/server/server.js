const jsonServer = require('json-server');
const server = jsonServer.create();
const productsCouponDB = jsonServer.router('./db/productsCouponDB.json');
const middlewares = jsonServer.defaults();
 
server.use(middlewares);
server.use(productsCouponDB);
server.listen(4000, () => {
  console.log('JSON Server is running')
});