<template>
  <div id="app">
    <Home/>
  </div>
</template>

<script>
import Home from './components/Home'
import './css/App.css'

export default {
  name: 'App',
  components: {
    Home
  }
}
</script>
