<template>
  <section>
    <h2>모든 폼 작성이 완료되었습니다.</h2>
    <h3>재작성을 원하시면 Restart를 클릭해 주세요.</h3>
    <h4>감사합니다.</h4>
  </section>
</template>

<script>
export default {
  name: 'Complete'
}
</script>
