## 설치

    터미널에 npm install 또는 yarn install 을 이용해서 모든 패키지를 설치 합니다.

## 실행

    npm start 또는 yarn start 를 입력하면 localhost:3000 포트에서 실행됩니다.

## 테스트 실행

    npm test 또는 yarn test 를 입력하면 테스트가 수행됩니다.