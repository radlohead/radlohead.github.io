<template>
  <div class="home">
    <MatchView />
  </div>
</template>

<script>
import MatchView from './MatchView'

export default {
  name: 'Home',
  components: {
    MatchView
  }
}
</script>
