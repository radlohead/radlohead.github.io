import React from 'react';

class Answer extends React.Component {
    render() {
        return (
            <aside className="answers">
                Answer..
            </aside>
        )
    }
}

export default Answer;