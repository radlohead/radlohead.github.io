module.exports = {
	fetch: require('./fetch.js'),
	submit: require('./submit.js')
};
