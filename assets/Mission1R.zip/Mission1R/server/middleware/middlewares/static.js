const express = require('express');

module.exports = express.static('static');
